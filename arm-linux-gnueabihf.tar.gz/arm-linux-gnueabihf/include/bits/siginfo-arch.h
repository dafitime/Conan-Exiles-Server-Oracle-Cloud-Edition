/* Architecture-specific adjustments to siginfo_t.  */
#ifndef _BITS_SIGINFO_ARCH_H
#define _BITS_SIGINFO_ARCH_H 1

/* This architecture has no adjustments to make to siginfo_t.  */

#endif
